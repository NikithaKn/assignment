import { Component, OnInit } from '@angular/core';
import { ProjService } from '../../services/proj.service';

@Component({
  selector: 'app-suggested-proj',
  templateUrl: './suggested-proj.component.html',
  styleUrls: ['./suggested-proj.component.css']
})
export class SuggestedProjComponent implements OnInit {

  imageResp = [];
  constructor(private service :ProjService ) { }
 
  ngOnInit() {
    this.service.getImages().subscribe( (resp:any) => {
       
      for(let i = 0 ; i <= 10 ; i++ ){
           this.imageResp.push(resp[i]);
      } 
      console.log(this.imageResp);
    })
  }

}
